Ông dev nào xài cái này thì tôi đố ông làm nó xuống 30s được=)
> *nếu được thì cho tui ké=)*
# 🎮 Auto Game Overfield

## ✨ Tính năng

- **Chạy map Lotus Courtyard trong ~70s** với chắc chắn 500 vàng cho mỗi lần chạy và XP
- **Tự động nhặt các drop của boss** qua thư

## 📥 Tải xuống

<div align="center">

[![Download ZIP](https://img.shields.io/badge/⬇️%20DOWNLOAD-ZIP%20FILE-brightgreen?style=for-the-badge&logo=github)](https://github.com/NamTranVN2719/auto/releases/download/v1.0.1/automatic9000.zip)

</div>

## 📖 Hướng dẫn sử dụng

### **Bước 1: Tải và giải nén**
Nhấn nút tải bên trên rồi giải nén ra một thư mục nào đó dễ nhớ. Nếu bạn không biết cách giải nén, xem [hướng dẫn này](https://youtu.be/D1AANWLh2ak?si=EJSB7fd43JejsWAI).

> *Lưu ý: Tui k có quảng cáo j đâu=)*

### **Bước 2: Điều chỉnh độ phân giải**
Script này chỉ hoạt động với màn hình **1920x1080**. Nếu bạn sử dụng màn hình khác, vui lòng chỉnh độ phân giải xuống. Tìm kiếm "làm cách nào để chỉnh độ phân giải màn hình" nếu cần=)

### **Bước 3: Đặt chế độ toàn màn hình**
Vào game và đặt chế độ toàn màn hình như sau:

![Fullscreen Mode](https://github.com/user-attachments/assets/806d61a9-4791-4589-afa1-0c710625fccd)

### **Bước 4: Đặt vị trí camera**
Dùng team ở ngoài là 1 người<br>
<img width="975" height="721" alt="image" src="https://github.com/user-attachments/assets/a9877c98-5bbb-4435-b8fc-e8a673a505fc" />

Đặt sẵn team trong Lotus Courtyard như sau:<br>
Slot 2,3: Dps<br>
Slot 1: Con nào cũng được lv cao tí <br>
ví dụ:<br>
<img width="949" height="407" alt="image" src="https://github.com/user-attachments/assets/cec1a205-d564-4ff7-9bfd-80c5dbe3923e" />

Tele đến vị trí trong hình vào 1 cái channel k người (thường là channel 4 số) và đặt camera sao cho giữ nút **W** mà không bị rớt:

![Camera Position](https://github.com/user-attachments/assets/6819b138-ec59-4599-a0b9-1d2b88684565)

### **Bước 5: Chạy script**
Chạy file tên là **"run"** trong thư mục bạn vừa giải nén. Sau đó, mọi thứ sẽ được tự động.
