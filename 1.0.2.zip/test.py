import sys
sys.path.insert(0, "./library")
import pyautogui
print(a)